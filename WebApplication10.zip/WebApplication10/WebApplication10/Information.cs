﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
namespace WebApplication10
{
    public class Information
    {
        [Key]
        public int productid { get; set; }

        public string productname { get; set; }

        public int categoryid { get; set; }
        public string categoryname { get; set; }
    }
   
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace WebApplication10.Context
{
    public class InformationdbContext:DbContext
    {
        public DbSet<Information> info { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Information>().MapToStoredProcedures();
            base.OnModelCreating(modelBuilder);
        }
    }
}